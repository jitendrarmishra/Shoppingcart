			
			<?php if($this->session->flashdata('registered')) : ?>
		<div class="alert alert-success">
		    <?php echo $this->session->flashdata('registered'); ?>
		</div>
		<?php endif; ?>
		<?php if($this->session->flashdata('pass_login')) : ?>
		<div class="alert alert-success">
		    <?php echo $this->session->flashdata('pass_login'); ?>
		</div>
		<?php endif; ?>

		<?php if($this->session->flashdata('fail_login')) : ?>
		<div class="alert alert-danger">
		    <?php echo $this->session->flashdata('fail_login'); ?>
		</div>
		<?php endif; ?>

		<div class="container">

		 <div class="row">
			 	<div class="col-md-3">
					<?php $this->load->view('sidebar'); ?>
				
				</div>
					
			 	

		  
				 	<div class="col-md-6">
					<div class="panel panel-default">
					<div class="panel-heading panel-heading-green">
						<h3 class="panel-title">All Compare List</h3>
					</div>
					<div class="panel-body">
<table>
				<tr>
		<?php foreach($products as $product) : ?>

			
					<td><img src="<?php echo $product->image; ?>" /><br>
						<b>Title :</b> <?php echo $product->title; ?><br>
					<b>Price :</b> <?php echo $product->price; ?><br>
	<b>Description :</b> <?php echo $product->description; ?><br>
				</td>


		
					
		<?php endforeach; ?>
	</tr>

			</table>

		
					
			 	</div>
			 	</div>
		</div>

	<div class="col-md-3">
					<?php $this->load->view('right_sidebar'); ?>
				
				</div>




	</div><!-- /.row -->
		
