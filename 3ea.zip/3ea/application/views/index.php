			
			<?php if($this->session->flashdata('registered')) : ?>
		<div class="alert alert-success">
		    <?php echo $this->session->flashdata('registered'); ?>
		</div>
		<?php endif; ?>
		<?php if($this->session->flashdata('pass_login')) : ?>
		<div class="alert alert-success">
		    <?php echo $this->session->flashdata('pass_login'); ?>
		</div>
		<?php endif; ?>

		<?php if($this->session->flashdata('fail_login')) : ?>
		<div class="alert alert-danger">
		    <?php echo $this->session->flashdata('fail_login'); ?>
		</div>
		<?php endif; ?>

		<div class="container">

		 <div class="row">
			 	<div class="col-md-3">
					<?php $this->load->view('sidebar'); ?>
				
				</div>
					
			 	

		  
				 	<div class="col-md-6">
					<div class="panel panel-default">
					<div class="panel-heading panel-heading-green">
						<h3 class="panel-title">All Products List</h3>
					</div>
					<div class="panel-body">

		<?php foreach($products as $product) : ?>
		<div class="col-md-6 game" style="border: solid 1px; margin-bottom: 10px; padding: 10px">
						<div class="game-price">$<?php echo $product->price; ?></div>
						<a href="<?php echo base_url(); ?>products/details/<?php echo $product->id; ?>">
							<img src="<?php echo $product->image; ?>" />
						</a>
						<div class="game-title">
							<?php echo $product->title; ?>
						</div>
						<div>
							<form method="post" action="<?php echo base_url(); ?>cart/add">
								Per Kg: <input class="qty" type="text" name="qty" value="1" /><br>
								<input type="hidden" name="item_number" value="<?php echo $product->id; ?>" />
								<input type="hidden" name="price" value="<?php echo $product->price; ?>" />
								<input type="hidden" name="title" value="<?php echo $product->title; ?>" />

								<!-- <div class="col-md-12 row"> -->
								<button style="margin-right: 5px" class="btn btn-primary col-md-3" name="action" value="cart" type="submit">Add to Cart</button>
								 <?php if($this->session->userdata('logged_in')) : ?>
								<button style="margin-right: 5px" class="btn btn-primary col-md-3" name="action" value="wishlist" type="submit">Wishlist</button>
								<?php  
							else :
								?>
								<button style="margin-right: 5px" class="btn btn-primary col-md-3" onclick="confirm('Kindly Login to add wishlist')" name="action" value="wishlist" type="button">Wishlist</button>
								 <?php endif; ?>
								
									<input style="width: 20px;height: 20px;margin-right: 5px" type="checkbox" class="compare" name="compare[]" value="<?php echo $product->id; ?>" ><b>Add to compare</b>
								
								<!-- </div> -->
							</form>				

						</div>
					</div>
					
		<?php endforeach; ?>


		
					
			 	</div>
			 	</div>
		</div>

	<div class="col-md-3">
					<?php $this->load->view('right_sidebar'); ?>
				
				</div>




	</div><!-- /.row -->
		
