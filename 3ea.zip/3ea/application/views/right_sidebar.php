<div class="cart-block">
				<form action="cart/update" method="post">
					<table cellpadding="6" cellspacing="1" style="width:100%" border="0">
						<tr>
							<th>Qty.</th>
							<th>Items</th>
							<th style="text-align:right">Item Price</th>
						</tr>
						<?php $i = 1; ?>
		<?php foreach ($this->cart->contents() as $items): ?>
			<input type="hidden" name="<?php echo $i.'[rowid]'; ?>" value="<?php echo $items['rowid']; ?>" />
				<tr>
	  				<td  valign="top"><input type="text" name="<?php echo $i.'[qty]'; ?>" value="<?php echo $items['qty']; ?>" maxlength="3" size="5" class="qty" /></td>
	  				<td valign="top"><?php echo $items['name']; ?></td>
	  				<td  valign="top" style="text-align:right"><?php echo $this->cart->format_number($items['price']); ?></td>
				</tr>
			<?php $i++; ?>
		<?php endforeach; ?>
		<tr>
  			<td></td>
  			<td class="right"><strong>Total</strong></td>
  			<td class="right" style="text-align:right">$<?php echo $this->cart->format_number($this->cart->total()); ?></td>
		</tr>
					</table>
				<br>
				<p><button class="btn btn-info" type="submit">Update Cart</button> 
				<a class="btn btn-info" href="cart">Go To Cart</a>
				<a class="btn btn-info" href="<?php echo site_url('cart/clear_cart') ?>">Clear Cart</a></p>
			</form>
		</div>

