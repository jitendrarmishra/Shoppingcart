
    <style>
       #fixedbutton {
    position: fixed;
    bottom: 0px;
    right: 0px; 
}
    </style>
 
   <a href="javascript:void(0)" class="btn btn-danger col-md-2 comparebutton" id="fixedbutton">Compare</a>

  </div><!-- /.container -->

<div style="clear: both"></div>
	  <div class="row footer">
		<div class="container">
			<p>3EA Test</p>
		</div>
	</div>


	<script type="text/javascript">
		var selected = [];

			$( document ).ready(function() {
				$(".comparebutton").hide();
				$(".compare").change(function() {
						if(this.checked) {
							$(".comparebutton").show();
						}
						else
						{
							$(".comparebutton").hide();
						}
				});

			});

	$(function () {
        function dumpInArray(){

           var arr = [];
           $('.compare:checked').each(function(){
              arr.push($(this).val());
           });
           console.log(arr);
           // exit();
           return arr; 
        }

        $('.comparebutton').click(function () {
           alldata = dumpInArray();
// alert(dumpInArray())
			$.ajax({
			type: "POST",
			url: '<?php echo site_url('products/add_compare') ?>',
			data: {"var":alldata},
			success: function (data) {
					$(location).attr('href', '<?php echo site_url('products/compare') ?>')

			},
			error: function (xhr, desc, err) {
			console.log('error');
			}
			});
        });
     });

	</script>
    
  </body>
</html>
