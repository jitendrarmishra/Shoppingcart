<?php
class User_model extends CI_Model{
    public function register(){
        $data = array(
            'first_name' => $this->input->post('first_name'),
            'last_name'  => $this->input->post('last_name'),
            'email'      => $this->input->post('email'),
            'user_type'      => $this->input->post('user_type'),
            'password'   => md5($this->input->post('password'))
        );
        $insert = $this->db->insert('users', $data);
        return $insert;
    }
    
    public function login($username, $password){
        //Validate
        $this->db->where('email', $username);
        $this->db->where('password', $password);
        
        $result = $this->db->get('users');

        // echo $this->db->last_query();
        // die;
        if($result->num_rows() == 1){
            return $result->row(0)->user_id;
        } else {
            return false;
        }
    }
    
}