<?php

class Products extends CI_Controller{
	public function index(){
		// $this->cart->destroy();
		//Get All Products
		$data['products'] = $this->Product_model->get_products();
		$this->load->view('header', $data);
		$this->load->view('index');
		$this->load->view('footer');
	}



	
	public function details($id){
		//Get Product Details
		$data['product'] = $this->Product_model->get_product_details($id);
		
		//Load View
		$this->load->view('header');
		$this->load->view('details', $data);
		$this->load->view('footer');
	}
	

		public function category(){
		//Get Category Products
		$category_id =	base64_decode($this->uri->segment(3));

		$data['category_name'] = $this->Product_model->category_name($category_id);
		$data['products'] = $this->Product_model->get_category_product($category_id);
		$this->load->view('header', $data);
		$this->load->view('category');
		$this->load->view('footer');
	}


	function add_compare()
	{
		$this->session->set_userdata('compareproducts' ,$this->input->post('var'));
		// print_r($this->session->all_userdata());

	}


	public function compare(){
		$all_p_id = $this->session->userdata('compareproducts');

		$data['products'] = $this->Product_model->get_product_compare($all_p_id);
		$this->load->view('header', $data);
		$this->load->view('compare');
		$this->load->view('footer');
	}



	
	
}